import Text from "../helper/Text";
import Media from "../helper/Media";
import banner from "./../../assets/images/cs_bg1_sec_01.jpg"
import Controller from "../helper/Controller";
import { TextControl } from '@wordpress/components';
import { sanitizeInput } from "../helper/Libs";
import PrimaryButton from "../Shared/PrimaryButton";

export const attributes = {
    title: {
        type: 'string',
        default: 'Your Title'
    },

    location: {
        type: 'string',
        default: 'Bali'
    },

    detail: {
        type: 'string',
        default: 'Anticipate the serenity of our upcoming property by the lakeside, where water mirrors the sky and time stands still. Perfect for those seeking reflection and calm.'
    },


    button: {
        type: 'string',
        default: '<a href="#">Invest with Us</a>'
    },

    banner: {
        type: 'image',
        default: {
            url: banner
        }
    },

    bannerMobile: {
        type: 'image',
        default: {
            url: banner
        }
    },
    customSectionClassName: {
        type: 'string',
        default: ''
    }
}

export default function (props) {
    const { headerColor, bannerMobile } = props.attributes;
    const { customSectionClassName } = props.attributes
    return (
        <>
            <Controller {...props}>
                <fieldset>
                    <div class="image-picker-wrapper">
                        <Media set="bannerMobile" {...props}></Media>
                    </div>
                </fieldset>
            </Controller>
            <section className={`grid featured-banner-two ${customSectionClassName}`} data-header-color={headerColor}>

                <div className="featured-banner-two__s1">
                    <Text tag="h3" className="featured-banner-two__s1__sb1" set="title" {...props} />
                    <div className="featured-banner-two__s1__sb2">
                        <div className="item">Location</div>
                        <Text className="item" set="location" {...props} />
                    </div>
                    <Text className="featured-banner-two__s1__sb3" set="detail" {...props} />
                    <PrimaryButton set="button" {...props} />
                </div>
                <Media set="banner" {...props} mobile="bannerMobile" />

            </section>
        </>
    )
}