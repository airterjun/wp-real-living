import PrimaryButton from "../Shared/PrimaryButton"
import TwoColumnText from "../TwoColumnText"
import Media from "../helper/Media"
import Text from "../helper/Text"
import banner01 from "./../../assets/images/img_vision_02.jpg"
import banner02 from "./../../assets/images/img_vision_01.jpg"

const attributes = {
    title: {
        type: 'string',
        default: 'Default Title'
    },
    description: {
        type: 'string',
        default: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
    },

    card: {
        type: 'array',
        default: [
            {
                title: 'Our Mission',
                description: 'To deliver immersive, enriching experiences that connect guests with the essence of their destination. Our mission is to create environments that serve as a "noise-canceling" sanctuary from the chaos of everyday life.',
                thumb: {
                    url: banner01
                }
            },

            {
                title: 'Our Vision',
                description: 'To lead in offering unique, visionary, and secluded experiences that integrate guests seamlessly with their environment. We aim to become the preferred choice for those seeking mindful and engaging getaways.',
                thumb: {
                    url: banner02
                }
            }
        ]
    },

    textBottom: {
        type: 'string',
        default: 'Discover how our unique approach works'
    },

    buttonServices: {
        type: 'string',
        default: '<a href="#">Our Servicves</a>'
    }
}


export default function (props) {

    const { card } = props.attributes

    const cards = () => card.map((item, index) => {
        const bannerKey = `card.${index}.thumb`
        const titleKey = `card.${index}.title`
        const descKey = `card.${index}.description`

        return <div className="vision__s1__card">
            <Media set={bannerKey} {...props} className="vision__s1__card__thumb v-parallax" />
            <div className="vision__s1__card__content">
                <Text set={titleKey} {...props} tag="h4" />
                <Text set={descKey} {...props} />
            </div>
        </div>
    })

    return (
        <section className="grid vision">
            <TwoColumnText {...props} />
            <div className="vision__s1">
                {cards()}
            </div>
            <Text set="textBottom" {...props} tag="div" className="vision__s2" />
            <PrimaryButton set="buttonServices" className="vision__s3" {...props} />
        </section>
    )
}

export {
    attributes
}