import "./style.scss";

import PrimaryButton from "../Shared/PrimaryButton";
import Text from "../helper/Text";
import ivan from "./../../assets/images/ivan_01.png"
import vlad from "./../../assets/images/vlad_01.png"
import background from "./../../assets/images/team_bg_01.jpg"
import Controller from "../helper/Controller";
import ButtonSlider from "../helper/ButtonSlider";
import { RichText } from '@wordpress/block-editor';
import _ from "lodash"

export const attributes = {
    card: {
        type: 'array',
        default: [
            {
                thumb: ivan,
                name: 'Ivan',
                position: 'Creator and Manager',
                description: `Ivan, the visionary Creator and Manager at Panoramika, brings a wealth of experience in hospitality sales and marketing, honed through a BA from the prestigious Swiss hospitality school GIHE. Ivan's role encompasses full operational and legal supervision, business development, quality assurance, architecture, design and construction supervision, recruitment, experience management, and R& D.His holistic approach ensures that Panoramika offers genuinely innovative experiences that prioritize privacy, discretion, and unparalleled guest comfort.`,
                listing: [
                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    }
                ]
            },

            {
                thumb: vlad,
                name: 'Vlad Bondarev',
                position: 'Co-founder',
                description: `Vlad brings a wealth of experience to Panoramika, combining his background in financial auditing, hotel management, and innovative environmental initiatives. As the Co-founder responsible for strategy and attracting investments, Vlad plays a crucial role in shaping the company’s vision and ensuring its growth. His dedication to providing exceptional experiences is evident in his approach to hospitality and investment opportunities, emphasizing genuine connections and tailored solutions for guests and partners alike.`,
                listing: [
                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    },

                    {
                        title: 'Favorite aspect of working<br/>at Panoramika?',
                        desc: 'Realizing my creative dreams<br/>and sharing them with the public.'
                    }
                ]
            }
        ]
    },

    description: {
        type: 'string',
        default: `With diverse backgrounds and a shared passion for excellence, our leaders guide the company in creating unique and immersive experiences for our guests. Meet the individuals whose expertise and commitment drive Panoramika's success.`
    },

    bottomText: {
        type: 'string',
        default: "Start Collaborating With Panoramika Today"
    },

    button: {
        type: 'string',
        default: "Contact Us"
    }
}



export default function (props) {

    const { card, headerColor } = props.attributes



    const listingText = (key) => card[key].listing.map((item, index) => {
        const title = `card.${key}.listing.${index}.title`
        const desc = `card.${key}.listing.${index}.desc`

        return <div className="team__s2__card__abc2 item">
            <Text tag="div" set={title} {...props} className="team__s2__card__abcd1" />
            <Text tag="div" set={desc} {...props} className="team__s2__card__abcd2" />
        </div>
    })

    const cards = () => card.map((item, i) => {
        const title = `card.${i}.name`
        const pos = `card.${i}.position`
        const desc = `card.${i}.description`

        return (
            <div className="team__s2__card">
                <div className="team__s2__card__a1">
                    <figure>
                        <img src={item.thumb} title={item.title} />
                    </figure>
                    <div className="team__s2__card__ab1">
                        <Text tag="h2" set={title} {...props} />
                        <Text set={pos} {...props} tag="div" className="team__s2__card__abc1" />
                        <Text tag="div" set={desc} {...props} className="team__s2__card__abc2" />
                    </div>
                </div>
                <div className="team__s2__card__a2">
                    <div className="team__s2__card__ab2 running-text">
                        {listingText(i)}
                    </div>
                </div>
            </div>
        )
    })


    const textEditor = () => card.map((item, index) => {
        const inputs = () => item.listing.map((t, i) => {

            const updateValue = (newVal, key) => {
                const clone = _.cloneDeep(card)
                _.set(clone, `${index}.listing.${i}.${key}`, newVal)
                props.setAttributes({
                    card: clone
                })
            }


            const retmoveItem = (litIndex, itemIndex) => {
                const clone = _.cloneDeep(card)
                clone[litIndex].listing.splice(itemIndex, 1)

                props.setAttributes({
                    card: clone
                })

            }

            return (
                <div class="input--wrapper">
                    <div className="button-delete dashicon dashicons dashicons-trash" onClick={() => {
                        retmoveItem(index, i)
                    }}></div>
                    <div className="input-container">
                        <RichText label="Q" value={t.title} onChange={(newContent) => {
                            updateValue(newContent, 'title')
                        }}></RichText>
                    </div>
                    <div className="input-container">
                        <RichText label="A" value={t.desc} onChange={(newContent) => {
                            updateValue(newContent, 'desc')
                        }}></RichText>
                    </div>
                </div>
            )
        })

        return (
            <div className="editor-group-inputs">
                <h3>{item.name}</h3>
                <div className="input">
                    {inputs()}
                </div>
                <ButtonSlider slider={`card.${index}.listing`} {...props} button={true} set="card" />
            </div>
        )
    })


    return (
        <>
            <Controller {...props}>
                <fieldset>
                    {textEditor()}
                </fieldset>
            </Controller>
            <section className="grid team" data-header-color={headerColor}>

                <figure className="team__s0 v-parallax no-scale">
                    <img src={background} />
                </figure>
                <div className="team__s1">
                    <div className="logo">
                        <div className="title">Leadership Team</div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 301.82 166.86"><path d="m166.71 136.18 102.2 14.27c.02 9.07 7.38 16.41 16.45 16.41s16.45-7.37 16.45-16.45-7.37-16.45-16.45-16.45c-3.72 0-7.14 1.25-9.89 3.33l-111.39-111c2.06-2.75 3.29-6.15 3.29-9.84C167.37 7.36 160 0 150.92 0s-16.45 7.37-16.45 16.45c0 3.7 1.23 7.09 3.29 9.84L26.34 137.28c-2.76-2.08-6.17-3.33-9.89-3.33C7.36 133.95 0 141.32 0 150.4s7.37 16.45 16.45 16.45 16.45-7.37 16.45-16.45c0-3.7-1.23-7.09-3.29-9.84L141.02 29.58c2.76 2.08 6.17 3.33 9.89 3.33s7.14-1.25 9.89-3.33l111.4 110.98a16.417 16.417 0 0 0-2.64 5.29l-102.2-14.27c-.02-9.07-7.38-16.41-16.45-16.41s-16.45 7.37-16.45 16.45 7.37 16.45 16.45 16.45c7.51 0 13.83-5.03 15.8-11.91Z" /></svg>
                    </div>
                    <Text set="description" {...props} className="description" />
                </div>
                <div className="team__s2">
                    {cards()}
                </div>

                <Text set="bottomText" className="team__s3" tag="div" {...props} />
                <PrimaryButton set="button" {...props} className="team__s4" />

            </section>
        </>
    )
}