import Media from "../helper/Media"
import Text from "../helper/Text"
import banner from "./../../assets/images/bg_con_em_01.jpg"
import mountain from "./../../assets/images/mountains_03_contact.png"

export const attributes = {
    title: {
        type: 'string',
        default: 'Email us directly at: '
    },

    email: {
        type: 'string',
        default: '<a href="mailto:info@discover-panoramika.com">info@discover-panoramika.com</a>'
    },

    image: {
        type: 'image',
        default: {
            url: banner
        }
    }
}

export default function (props) {
    const { headerColor } = props.attributes;
    return (
        <section className="grid contact-us-banner" data-header-color={headerColor}>
            <div className="contact-us-banner__s1">
                <Text set="title" {...props} className="contact-us-banner__s1__title" />
                <Text set="email" {...props} className="contact-us-banner__s1__email" />
            </div>
            <Media set="image" {...props} className="contact-banner-parallax" />
            <figure className="contact-banner-parallax layer" >
                <img src={mountain} />
            </figure>
            <div class="scale--corner --white" data-trigger="bottom"></div>
        </section>
    )
}