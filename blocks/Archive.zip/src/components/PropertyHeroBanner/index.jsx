
import Jumbotron from "./../Jumbotron"
import placeholder from "./../../assets/images/banner-placeholder.jpeg"
import lantern from "./../../assets/images/hdr_ele_01.png"

export const attributes = {
    title: {
        type: 'string',
        default: 'Our Properties',
    },
    background: {
        type: 'image',
        default: {
            url: placeholder
        },
    }
}


export default function (props) {
    const lanterns = () => [1, 2, 3, 4, 5].map((item, index) => {
        return <img src={lantern} className={`lantern--${index}`} width="125" height="950"></img>
    })
    return (
        <section className="property-her-banner">
            <div className="lantern">
                {lanterns()}
            </div>
            <Jumbotron {...props} />
        </section>
    )

}