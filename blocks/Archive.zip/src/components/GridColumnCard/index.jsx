import "./style.scss";
import ButtonSlider from "../helper/ButtonSlider"
import Media from "../helper/Media"
import Text from "../helper/Text"
import Controller from "../helper/Controller";
import banner from "./imgs/riv_bis_dt_01.jpg"
import { ColorPicker } from '@wordpress/components';
import _ from "lodash"
const attributes = {
    list: {
        type: 'array',
        default: [
            {
                title: 'Bistro',
                location: 'Berawa',
                description: `Riviera Bistro is a beacon of sophistication and vibrancy in the bustling neighborhood of Berawa. Renowned for its seamless fusion of contemporary design and Mediterranean cuisine, it’s the perfect destination for those who appreciate a lively yet refined dining. `,
                thumb: {
                    url: banner
                },
                button: "Learn More",
                color: '#000'
            }
        ]
    }
}

export default function (props) {
    const { headerColor } = props.attributes;
    const { list } = props.attributes
    const grid = () => list.map((item, index) => {
        const keyTitle = `list.${index}.title`
        const keyLocation = `list.${index}.location`
        const keyDesc = `list.${index}.description`
        const thumb = `list.${index}.thumb`
        const link = `list.${index}.button`
        return (
            <div className="card-wrapper">
                <div className="header">
                    <div style={{ color: item.color }}>
                        <Text tag="h2" set={keyTitle} {...props} />
                    </div>
                    <Text set={keyLocation} {...props} />
                </div>
                <Media set={thumb} {...props} className="v-parallax" />
                <div className="card__content">
                    <Text set={keyDesc} {...props} />
                    <div className="button">
                        <Text tag="a" set={link} {...props} />
                    </div>
                </div>
            </div>
        )
    })


    const cardColorPicker = () => list.map((item, index) => {
        const model = `${index}.color`

        const listClone = structuredClone(list)

        const setColorText = (color) => {
            _.set(listClone, model, color)

            props.setAttributes({
                ...list,
                list: listClone
            });
        }

        return <div className="listing">
            <div className="label">{item.title}</div>
            <ColorPicker color={item.color}
                onChangeComplete={(color) => setColorText(color.hex)}
                disableAlpha />
        </div>

    })


    return (
        <>
            <Controller {...props}>
                <div className="inner card-list-editor-color">
                    {cardColorPicker()}
                    <ButtonSlider slider="list" {...props} />
                </div>
            </Controller>

            <section className="grid grid-col-card" data-header-color={headerColor}>
                <div className="inner">
                    <div className="group">
                        {grid()}
                    </div>
                </div>
            </section>
        </>

    )
}


export {
    attributes
}