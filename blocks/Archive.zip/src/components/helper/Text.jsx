import _ from "lodash"
import { getBaseModelPath } from "./Libs";

import { RichText } from '@wordpress/block-editor';

export default function Text(props) {
    const { edit, attributes, set, setAttributes, className } = props
    let tag = props.tag
    let newLine = 'br'
    let getVal = _.get(attributes, set)

    if (!getVal && edit) {
        getVal = "Write here..."
    }

    if (props.multiline) {
        newLine = props.multiline
    }

    if (!tag) tag = 'p'

    if (!edit) {
        return getVal ?
            <RichText.Content tagName={tag}
                className={className}
                value={getVal} /> : ''
    } else {

        const updateContentVal = newVal => {
            const path = getBaseModelPath(set)
            const copy = _.cloneDeep(attributes)
            _.set(copy, set, newVal)
            setAttributes({
                [path]: copy[path]
            })
        }

        return (
            <RichText tagName={tag}
                className={className}
                value={getVal}
                onChange={(newValue) => {
                    updateContentVal(newValue)
                }} />
        )
    }
}
