import _ from "lodash"
/**
 * @param path {String}
 * @return string
 */
export const getBaseModelPath = (path) => {
    let base = path
    if (path.includes('.')) {
        const paths = path.split('.')
        base = _.first(paths)
    }
    return base
}

export const getModel = (path) => {
    let base = path
    if (path.includes('.')) {
        const paths = path.split('.')
        base = _.last(paths)
    }
    return base
}


export const sanitizeInput = (input) => {
    // Basic client-side sanitization example
    return input.replace(/[^a-zA-Z0-9 -]/g, '');
}
