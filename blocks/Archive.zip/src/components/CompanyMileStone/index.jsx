import Text from "../helper/Text"
import bullet from "./../../assets/images/tl_spot_01.png"

export const attributes = {
    title: {
        type: 'string',
        default: 'Company Milestones'
    },

    milestone: {
        type: 'array',
        default: [
            {
                year: 'January 2021',
                detail: 'Panoramika is founded.'
            },

            {
                year: 'August 2023',
                detail: 'Launch of Aurora Cabins, achieving operational profitability within three months.'
            },

            {
                year: 'April 2024',
                detail: `Aurora Cabins' Instagram account exceeds 4,000 organic followers.`
            },

            {
                year: 'April 2024',
                detail: `Surpassed business plan revenue and profit projections, operating at 25% above expectations.`
            },

            {
                year: 'August 2024',
                detail: `Start of construction for the second phase of Aurora Cabins, with completion expected by May 2025.`
            },

            {
                year: 'May 2024',
                detail: `Signed a contract for the second phase of Aurora Cabins, doubling the initially planned investment volume.`
            }
        ]
    }
}

export default function (props) {
    const { milestone } = props.attributes

    const miles = () => milestone.map((item, index) => {
        return (
            <div className={`milestone__list_a a--${index}`}>
                <div className="group">
                    <div className="group--year">{item.year}</div>
                    <div className="group--detail">{item.detail}</div>
                </div>
                <img src={bullet} />
            </div>
        )
    })

    return (
        <section className="grid milestone">
            <div className="milestone__header">
                <svg xmlns="http://www.w3.org/2000/svg" id="txt" viewBox="0 0 331.79 42.97"><defs></defs><path d="m42.93 35.07 26.32 3.67a4.24 4.24 0 1 0 4.24-4.25c-.96 0-1.84.32-2.55.86L42.25 6.77c.53-.71.85-1.58.85-2.53C43.1 1.9 41.2 0 38.86 0s-4.24 1.9-4.24 4.24c0 .95.32 1.83.85 2.53L6.78 35.35a4.19 4.19 0 0 0-2.55-.86c-2.34 0-4.24 1.9-4.24 4.24s1.9 4.24 4.24 4.24 4.24-1.9 4.24-4.24c0-.95-.32-1.83-.85-2.53L36.31 7.62c.71.54 1.59.86 2.55.86s1.84-.32 2.55-.86L70.1 36.2c-.3.4-.54.86-.68 1.36L43.1 33.89a4.24 4.24 0 1 0-4.24 4.25c1.93 0 3.56-1.3 4.07-3.07ZM104.65 11.6c-.98-.37-2.55-.54-4.93-.54h-4.96v21.33H97v-9.87h2.04c2.7 0 5.07-.08 6.65-1.07 1.58-.99 2.48-2.7 2.48-4.69 0-2.39-1.32-4.32-3.52-5.17Zm-.02 7.87c-.9.73-2.21.88-4.16.88h-1.1c-.77 0-1.56.01-2.36 0v-7.1h3.7c1.53 0 2.87.06 3.84.79.81.63 1.31 1.68 1.31 2.74s-.49 2.12-1.22 2.71ZM121.55 11.07h-.57l-10.07 21.26-.04.08h2.49l3.31-6.98h9.09l3.33 6.95v.03h2.41l-9.94-21.3v-.03Zm3.22 12.18h-7.1l3.58-7.5 3.52 7.5ZM152.57 27.23 138.6 11.09l-.02-.02h-.52V32.4h2.24V16.44l13.94 15.94.02.02h.55V11.07h-2.24v16.16zM173.6 10.54c-6.21 0-11.08 4.96-11.08 11.29s4.95 11.11 11.26 11.11 11.23-4.92 11.23-11.2c0-3.07-1.16-5.91-3.28-7.98-2.11-2.07-5-3.22-8.13-3.22Zm9.08 11.17c0 5.16-3.85 9.05-8.96 9.05s-8.87-3.92-8.87-8.93c0-5.7 4.51-9.11 8.87-9.11 2.3 0 4.57.91 6.23 2.49 1.76 1.68 2.73 3.99 2.73 6.5ZM205.55 19.42c.48-.96.63-1.58.63-2.66 0-2.4-1.32-4.33-3.52-5.17-.98-.37-2.56-.54-4.96-.54h-4.93v21.33h2.24v-9.87h1.13l7.61 9.85.02.02h2.77l-7.66-9.87c3.61-.02 5.61-.95 6.68-3.1Zm-1.7-2.66c0 1.05-.48 2.08-1.25 2.71-.99.79-2.57.9-4.13.9-.55 0-1.12 0-1.71-.01-.57 0-1.17-.01-1.75-.01v-7.1h4.29c2.9 0 4.56 1.28 4.56 3.52ZM223.23 11.07h-.57l-10.07 21.26-.04.08h2.49l3.31-6.98h9.09l3.33 6.95v.03h2.41l-9.94-21.3v-.03Zm3.22 12.18h-7.1l3.58-7.5 3.52 7.5ZM260.29 11.07h-.43l-8.51 17.34-8.58-17.31-.02-.03h-.43l-3.03 21.27-.01.06h2.18l2.03-15.18 7.54 15.15.02.03h.6l7.44-15.06 2.05 15.06h2.18l-3.02-21.29-.01-.04zM270.88 11.07h2.24V32.4h-2.24zM295.26 11.16l.1-.09h-3.03l-8.4 7.88v-7.88h-2.24V32.4h2.24v-9.82l9.24 9.8.02.02h2.96L285.1 20.64l10.16-9.48zM312.37 11.07h-.57l-10.07 21.26-.04.08h2.49l3.31-6.98h9.09l3.33 6.95v.03h2.41l-9.94-21.3v-.03Zm3.22 12.18h-7.1l3.58-7.5 3.52 7.5ZM323.01 10.58h1.02v4.07h.56v-4.07h1v-.55h-2.58v.55zM331.14 10.08l-.01-.05h-.15l-1.78 3.63-1.78-3.6-.02-.03h-.16l-.65 4.62h.55l.41-3.12 1.56 3.12h.18l1.53-3.1.42 3.1h.55l-.65-4.57z" /></svg>
                <Text className="header__s1" set="title" {...props} />
            </div>
            <div className="milestone__list">
                <div className="milestone__list__s">
                    {miles()}
                </div>
            </div>
            <div class="scale--corner --white --top" data-trigger="top"></div>
        </section>
    )
}