import React from 'react'
import Text from "../helper/Text";
import banner from "./../../assets/images/hm_ele_01.jpg"

const attributes = {
    title: {
        type: 'string',
        default: 'Discover the Art of Escape with Panoramika'
    },
    deteail: {
        type: 'string',
        default: `Embark on a journey of discovery with Panoramika. Each of our properties is a gateway to unique experiences, designed to blend local charm with unparalleled luxury. We offer a sanctuary where you can relax, rejuvenate, and reconnect with what matters most.
From the lush, serene valleys of our countryside retreats to the bustling heartbeats of our urban escapes, Panoramika promises more than just a stay—it promises a voyage into the essence of each locale. Our destinations are carefully selected to immerse you in environments that inspire and revitalize.
Dive into bespoke services tailored to your every need. Whether it's a spa day framed by breathtaking views or a culinary tour led by world-class chefs, Panoramika curates experiences that cater to every guest's desires, ensuring every moment of your stay is memorable.`
    }
}
const Discover = (props) => {
    const { headerColor } = props.attributes;
    return (
        <section className="discover grid" data-header-color={headerColor}>
            <Text tag="h2" set="title" {...props} className="discover__s1" />
            <Text tag="div" set="deteail" {...props} className="discover__s2" />
            <img src={banner} className='parallax-offset-up' />
        </section>
    )
}


export default Discover
export {
    attributes
}
