import './style.scss'
import Text from "../helper/Text"
import PrimaryButton from '../Shared/PrimaryButton'

const attributes = {
   label: {
      type: 'string',
      default: ''
   },
   title: {
      type: 'string',
      default: 'Default Title'
   },
   description: {
      type: 'string',
      default: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
   },
   button: {
      type: 'string',
      default: '<a href="#">Contact us</a>'
   }
}

const TwoColumnText = (props) => {
   const { button } = props

   return (
      <section className="two-column-text grid">
         <div className="two-column-text__s1 double-border-bottom">
            <Text tag="div" className="label" set="label" {...props} />
            <Text tag="h2" set="title" {...props} />
         </div>
         <div className="two-column-text__s2">
            <Text tag="div" set="description" {...props} />
            <div className='button'>
               <Text tag="a" set="button" {...props} />
            </div>
         </div>
      </section>
   )
}

export default TwoColumnText
export {
   attributes
}
