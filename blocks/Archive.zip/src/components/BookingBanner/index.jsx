import React from 'react'
import './index.scss'

import Text from "../helper/Text";
import Logo from "../Shared/logo"
import bg from "./assets/ac_bg_01.jpg"
import cabin from "./assets/ac_cabins_01.png"
import PrimaryButton from '../Shared/PrimaryButton';


const attributes = {
    topText: {
        type: 'string',
        default: 'Now Open'
    },

    description: {
        type: 'string',
        default: 'Nestled in the lush greenery of Bali, Aurora Cabins offers a serene escape from the everyday. Immerse yourself in the tranquility of nature and experience personalized comfort.'
    },

    buttonBooking: {
        type: 'string',
        default: '<a href="#">Book Now</a>'
    },

    buttonMore: {
        type: 'string',
        default: '<a href="#">Lear More</a>'
    }
}

const BookingBanner = (props) => {
    const { headerColor } = props.attributes;
    return (

        <section className="grid booking-banner" data-header-color={headerColor}>
            <Text set="topText" {...props} className='booking-banner__s1' />
            <div className='booking-banner__s2'>
                <Logo />
                <div className='booking-banner__s2__brand-name'>
                    Aurora Cabins

                    <div className='booking-banner__s2__location'>
                        <span>Jatiluwih</span>
                        <span>Bali</span>
                    </div>
                </div>
            </div>
            <Text tag="div" set="description" {...props} className="booking-banner__s3" />
            <div className='booking-banner__s4'>
                <PrimaryButton {...props} set="buttonBooking" />
                <Text set="buttonMore" className="button-more" {...props} />
            </div>
            <figure className='booking-banner__s5'>
                <img src={bg}></img>
            </figure>
            <figure className='booking-banner__s6'>
                <img src={cabin}></img>
            </figure>
        </section>
    )
}

export default BookingBanner
export {
    attributes
}