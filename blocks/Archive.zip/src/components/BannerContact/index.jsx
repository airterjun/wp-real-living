import PrimaryButton from "../Shared/PrimaryButton";
import Text from "../helper/Text";
import banner from "./../../assets/images/pnr_sec_bg_01.jpg"

export const attributes = {
    title: {
        type: 'string',
        default: 'Become Part of the Panoramika Experience'
    },

    detail: {
        type: 'string',
        default: `At Panoramika, every property is more than just a destination; it's an invitation to experience the extraordinary.As we continue to expand and innovate, we invite you to be part of our story.Whether as a guest seeking unique escapes or as an investor looking to grow with us, your journey with Panoramika promises to be nothing short of transformative.Discover, invest, and grow as we explore new horizons together.Your next great adventure starts here.`
    },

    button: {
        type: 'string',
        default: '<a href="#">Contact us</a>'
    }
}

export default function (props) {
    const { headerColor } = props.attributes;
    return (

        <section className="grid banner-contact" data-header-color={headerColor}>
            <div className="group">
                <Text set="title" tag="h2" className="group__s1" {...props} />
                <Text set="detail" tag="div" className="group__s2" {...props} />
                <PrimaryButton set="button" {...props} class="group__s3" />
            </div>
            <figure>
                <img src={banner} />
            </figure>
            <div class="scale--corner --white --top" data-trigger="top"></div>
        </section>
    )
}