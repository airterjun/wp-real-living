import "./style.scss";

import image_one from "./imgs/foreground_01.png"
import image_two from "./imgs/mtn_01.png"
import image_three from "./imgs/mtn_02.png"
export const attributes = {}
export default function () {
    return (
        <section className="homepage-hero-banner">
            <div className="parallax-3d">
                <img src={image_one} />
            </div>
            <div className="parallax-3d">
                <img src={image_two} />
            </div>
            <div className="parallax-3d">
                <img src={image_three} />
            </div>
        </section>
    )
}