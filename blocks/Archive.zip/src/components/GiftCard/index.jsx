import React from 'react'
import Text from "../helper/Text";
import Media from "../helper/Media";
import Logo from "../Shared/logo"
import placeholder from "./../../assets/images/ac_sec_bg_01.jpg"
import ButtonSlider from '../helper/ButtonSlider';
import Mountain from '../Shared/Mountain';
import PrimaryButton from '../Shared/PrimaryButton';


const attributes = {
  tag: {
    type: 'string',
    default: 'Your <b>Booking Details</b> at',
  },

  background: {
    type: 'image',
    default: {
      url: placeholder
    }
  },

  bookRefTitle: {
    type: 'string',
    default: 'Booking Reference'
  },

  bookRef: {
    type: 'string',
    default: 'Orion-001'
  },

  guestName: {
    type: 'string',
    default: '<span>Dear</span> <b>Guest Name</b>,'
  },

  guestContent: {
    type: 'string',
    default: 'Your journey to tranquility begins here. This page contains the details of your upcoming stay at Aurora Cabins. We’ve ensured that everything is prepared for your visit to ensure a memorable and restful escape.'
  },

  contentsLeft: {
    type: 'string',
    default: `Escape to Aurora Cabins in Jatiluwih, where tranquility and nature blend seamlessly. Set amidst Bali's lush landscapes, these cabins provide a serene retreat.`,
  },

  contentsRight: {
    type: 'string',
    default: `Located in the heart of Bali's serene Jatiluwih region, Aurora Cabins offers a unique getaway immersed in nature. Each cabin is designed to provide solitude and peace.`,
  },

  buttonWebsite: {
    type: 'string',
    default: `<a href="#">Aurora Cabins website</a>`,
  },

  buttonInstagram: {
    type: 'string',
    default: `<a href="#">Instagram</a>`,
  },

  list: {
    type: 'array',
    default: [
      {
        title: 'Date',
        detail: '30th September, 2024'
      },

      {
        title: 'Number of Nights',
        detail: '5'
      },
    ]
  },
  gallery: {
    type: 'array',
    default: [
      {
        url: "./../../assets/images/imageright.jpeg"
      },

      {
        url: "./../../assets/images/imageright.jpeg"
      },
    ]
  }
}
export default function (props) {

  const { list, gallery } = props.attributes
  const { headerColor, buttonWebsite, buttonInstagram } = props.attributes;

  const listItem = () => list.map((item, index) => {
    const updateKey = `list.${index}.title`
    const updateKeyValue = `list.${index}.detail`
    return (
      <div className={`list--item list--item--${index}`}>
        <Text set={updateKey} {...props} tag="div" className="list--item__title" />
        <div className='list--item__sparator'>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33.48 45.08"><path d="M16.24-5.06h1v55.2h-1z" transform="rotate(-36.29 16.737 22.55)" /></svg>
        </div>
        <Text set={updateKeyValue} {...props} tag="div" className="list--item__value" />
      </div>
    )
  })

  const galleryList = () => gallery.map((item, index) => {
    const updateKey = `gallery.${index}`
    return <div className="swiper-slide"><Media set={updateKey} {...props} /></div>
  })

  return (
    <section className='grid gift-card' data-header-color={headerColor}>
      <div className="gift-card__s0">
        <Text set="guestName" {...props} tag="div" className="guest-name" />
        <Text set="guestContent" {...props} tag="div" className="guest-content" />
      </div>

      <div className="gift-card__s01">
        <Text set="bookRefTitle" {...props} tag="div" className="book-ref-title" />
        <Text set="bookRef" {...props} tag="div" className="book-ref" />
      </div>

      <Text set="tag" {...props} tag="div" className="gift-card__s1" />
      <Logo className="gift-card__s2" />

      <div className='gift-card__s3'>
        Aurora Cabins
        <div className='location'>
          <span>Jatiluwih</span>
          <span>Bali</span>
        </div>
      </div>
      <div className='grid item-list-wrapper'>
        {listItem()}
      </div>
      <div className='carousel-gallery swiper'>
        <ButtonSlider slider="gallery" {...props} />
        <div className='swiper-wrapper'>
          {galleryList()}
        </div>
      </div>
      <div className='background v-parallax no-scale'>
        <Mountain />
      </div>

      <Text set="contentsLeft" {...props} className="gift-card__s4" tag="div" />
      <Text set="contentsRight" {...props} className="gift-card__s5" tag="div" />
      {/* <PrimaryButton class="gift-card__s6" set="buttonBook" {...props} /> */}

      <div class="gift-card__button-group">

        <div class="round-button">
          <div class="button primary-button">
            <div class="original button__styled">
              <p class="stagger">
                <a href="https://discover-panoramika.com" className='desktop'>Aurora Cabins Website</a>
                <a href="https://discover-panoramika.com" className='mobile'>Website</a>
              </p>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <polyline points="14 19 21 12 14 5" fill="none" stroke="#000" stroke-miterlimit="10"></polyline>
                <line x1="21" y1="12" x2="2" y2="12" fill="none" stroke="#000" stroke-miterlimit="10"></line>
              </svg>
            </div>
            <div class="copied button__styled">
              <p class="stagger">
                <a href="https://discover-panoramika.com" className='desktop'>Aurora Cabins Website</a>
                <a href="https://discover-panoramika.com" className='mobile'>Website</a>
              </p>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <polyline points="14 19 21 12 14 5" fill="none" stroke="#000" stroke-miterlimit="10"></polyline>
                <line x1="21" y1="12" x2="2" y2="12" fill="none" stroke="#000" stroke-miterlimit="10"></line>
              </svg>
            </div>
          </div>
        </div>

        <div class="gift-card__button ig-button">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill-rule="evenodd" clip-rule="evenodd" d="M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" fill="#000"></path> <path d="M18 5C17.4477 5 17 5.44772 17 6C17 6.55228 17.4477 7 18 7C18.5523 7 19 6.55228 19 6C19 5.44772 18.5523 5 18 5Z" fill="#000"></path> <path fill-rule="evenodd" clip-rule="evenodd" d="M1.65396 4.27606C1 5.55953 1 7.23969 1 10.6V13.4C1 16.7603 1 18.4405 1.65396 19.7239C2.2292 20.8529 3.14708 21.7708 4.27606 22.346C5.55953 23 7.23969 23 10.6 23H13.4C16.7603 23 18.4405 23 19.7239 22.346C20.8529 21.7708 21.7708 20.8529 22.346 19.7239C23 18.4405 23 16.7603 23 13.4V10.6C23 7.23969 23 5.55953 22.346 4.27606C21.7708 3.14708 20.8529 2.2292 19.7239 1.65396C18.4405 1 16.7603 1 13.4 1H10.6C7.23969 1 5.55953 1 4.27606 1.65396C3.14708 2.2292 2.2292 3.14708 1.65396 4.27606ZM13.4 3H10.6C8.88684 3 7.72225 3.00156 6.82208 3.0751C5.94524 3.14674 5.49684 3.27659 5.18404 3.43597C4.43139 3.81947 3.81947 4.43139 3.43597 5.18404C3.27659 5.49684 3.14674 5.94524 3.0751 6.82208C3.00156 7.72225 3 8.88684 3 10.6V13.4C3 15.1132 3.00156 16.2777 3.0751 17.1779C3.14674 18.0548 3.27659 18.5032 3.43597 18.816C3.81947 19.5686 4.43139 20.1805 5.18404 20.564C5.49684 20.7234 5.94524 20.8533 6.82208 20.9249C7.72225 20.9984 8.88684 21 10.6 21H13.4C15.1132 21 16.2777 20.9984 17.1779 20.9249C18.0548 20.8533 18.5032 20.7234 18.816 20.564C19.5686 20.1805 20.1805 19.5686 20.564 18.816C20.7234 18.5032 20.8533 18.0548 20.9249 17.1779C20.9984 16.2777 21 15.1132 21 13.4V10.6C21 8.88684 20.9984 7.72225 20.9249 6.82208C20.8533 5.94524 20.7234 5.49684 20.564 5.18404C20.1805 4.43139 19.5686 3.81947 18.816 3.43597C18.5032 3.27659 18.0548 3.14674 17.1779 3.0751C16.2777 3.00156 15.1132 3 13.4 3Z" fill="#000"></path> </g></svg>
          <Text set="buttonInstagram" {...props} className="button-title" />

          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className='mobile'>
            <polyline points="14 19 21 12 14 5" fill="none" stroke="#000" stroke-miterlimit="10"></polyline>
            <line x1="21" y1="12" x2="2" y2="12" fill="none" stroke="#000" stroke-miterlimit="10"></line>
          </svg>
        </div>

      </div>


      {/* <Text set="buttonWebsite" {...props} className="gift-card__s7 desktop" /> */}
      {/* <p class="gift-card__s7 stagger mobile"> */}
      {/*   <a href={buttonWebsite}>Website</a> */}
      {/* </p> */}
    </section>
  )

}


export {
  attributes
}
