import Text from "../helper/Text"
import circle from "./../../assets/images/hdr_bg_2_02.png"
import moon from "./../../assets/images/moon.png"

export const attributes = {
    title: {
        type: 'string',
        default: 'About Us',
    }
}

export default function (props) {
    return (
        <section className="grid about-us-hero">
            <Text set="title" {...props} tag="h1" />
            <figure className="b-parallax main-circle">
                <img src={circle} />
            </figure>
            <div className="pink-planet b-parallax"></div>
            <figure className="b-parallax moon">
                <img src={moon} />
            </figure>
        </section>
    )
}

