import React from 'react'
import Text from "../helper/Text";
import dna from "./assets/info_bg_02.jpg"
import bg from "./assets/tg_bg_01.jpg"
import PrimaryButton from '../Shared/PrimaryButton';
import Controller from '../helper/Controller';
import { TextareaControl } from "@wordpress/components"

const attributes = {
  title: {
    type: 'string',
    default: `We Create Environments That Enhances Nature's Harmony.`,
  },

  mobiletTitle: {
    type: 'string',
    default: `We Create Environments That Enhances Nature's Harmony.`,
  },

  subTitle: {
    type: 'string',
    default: 'Secluded Sanctuaries Designed for Deep Connection'
  },

  description: {
    type: 'string',
    default: `Step into secluded retreats where the starlit sky unfolds above and nature's tranquility surrounds you. At Panoramika, we create spaces that deepen your connection with nature and yourself. Experience serene landscapes and bespoke services designed to harmonize with the natural world, offering moments of reflection, relaxation, and rejuvenation.`
  },

  button: {
    type: 'string',
    default: `<a href="#">Learn More</a>`
  }
}

const ContactForm = (props) => {
  const { setAttributes, attributes } = props
  const { headerColor, mobiletTitle } = attributes;
  return (
    <>
      <Controller {...props}>
        <fieldset>
          <TextareaControl label="Mobile Title"
            value={mobiletTitle}
            onChange={(content) => setAttributes({ mobiletTitle: content })}
            rows="5" />
        </fieldset>
      </Controller>
      <section className="featured grid" data-header-color={headerColor}>
        <div className='featured__bg'>
          <figure className='v-parallax no-scale'>
            <img src={bg} />
          </figure>
          <div class="scale--corner --white" data-trigger="top"></div>
        </div>
        <Text set="title" {...props} tag="h2" className="featured__s1 desktop" />
        <h2 className="featured__s1 mobile">
          {mobiletTitle}
        </h2>
        <div className='featured__s2'>
          <Text set="subTitle" {...props} tag="h3" className="featured__s2__heading" />
          <Text set="description" {...props} tag="div" className="featured__s2__description" />
          <PrimaryButton {...props} set="button" class="featured__s2__button" />
        </div>
        <figure className='featured__dna'>
          <img src={dna} />
        </figure>
      </section>
    </>
  )
}

export default ContactForm
export {
  attributes
}
