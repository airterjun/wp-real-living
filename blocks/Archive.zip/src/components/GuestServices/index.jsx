import TwoColumnText from "../TwoColumnText";
import banner from "./../../assets/images/pnr_srv_bg_02.jpg"
import Text from "../helper/Text"
import PrimaryButton from "../Shared/PrimaryButton";

export const attributes = {
    items: {
        type: 'array',
        default: [
            {
                title: 'Attention to Detail',
                description: 'Every service is executed with the highest level of detail and elegance, ensuring guest satisfaction.'
            },

            {
                title: 'Cultural Authenticityl',
                description: 'Services are infused with local traditions and practices, providing a deep and authentic experience of the locale.'
            },

            {
                title: 'Flexibility and Customization',
                description: 'Understanding that each guest is unique, our services are highly customizable to suit individual tastes and needs.'
            }
        ]
    },
    subTitle: {
        type: 'string',
        default: 'Experience the Panoramika services'
    },
    button: {
        type: 'string',
        default: '<a href="#">Book now</a>'
    },
    title: {
        type: 'string',
        default: 'Guest Services'
    },
    description: {
        type: 'string',
        default: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
    }
}


export default function (props) {
    const { headerColor } = props.attributes;
    const content = () => props.attributes.items.map((item, index) => {
        const keyTitle = `items.${index}.title`
        const keyDesc = `items.${index}.description`
        return (
            <div className="card">
                <Text set={keyTitle} {...props} tag="h3" />
                <Text set={keyDesc} {...props} />
            </div>
        )
    })
    return (
        <section className="guest-services" data-header-color={headerColor}>
            <TwoColumnText {...props} />
            <section className="grid">
                <div className="items">
                    {content()}
                </div>
            </section>
            <div className="group">
                <Text set="subTitle" {...props} className="group__text" />
                <PrimaryButton set="button" {...props} />
            </div>

            <figure>
                <img src={banner} />
            </figure>
            <div class="scale--corner --white" data-trigger="top"></div>
        </section>
    )
}