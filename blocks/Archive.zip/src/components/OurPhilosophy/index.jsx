import PrimaryButton from "../Shared/PrimaryButton"
import Text from "../helper/Text"
import banner from "./../../assets/images/phi_bg_01.jpg"

export const attributes = {
    title: {
        type: "string",
        default: 'Our Core<br/>Philosophy'
    },
    description: {
        type: "string",
        default: 'At Panoramika, our core philosophy is centered on creating exceptional and memorable experiences for our guests. We believe in providing a harmonious blend of innovation, privacy, and unparalleled service. By focusing on the finer details, we craft environments that not only meet but exceed the expectations of discerning travelers.'
    },

    card: {
        type: "array",
        default: [
            {
                title: 'Strong<br/>Connection',
                description: 'We create powerful connections, turning every stay into a memorable experience that allows guests to reconnect with themselves and their environment.'
            },

            {
                title: 'Unique Experiences',
                description: 'Our properties are designed to offer authentic and immersive experiences, stimulating exploration, curiosity, and a sense of connection with the setting.'
            },

            {
                title: 'Service Excellence',
                description: 'Every interaction is tailored to meet the very best hospitality standards, ensuring that each guest feels valued and cared for.'
            }
        ]
    },

    buttonBook: {
        type: "string",
        default: 'Book Now'
    },


    buttonWebsite: {
        type: "string",
        default: 'Aurora Cabins website'
    }
}

export default function (props) {
    const { card, headerColor } = props.attributes
    const cards = () => card.map((item, index) => {
        const titleKey = `card.${index}.title`
        const descriptionKey = `card.${index}.description`
        return (
            <div className="philoshophy__s3__sub">
                <Text set={titleKey} {...props} tag="h4" />
                <Text set={descriptionKey} {...props} />
            </div>
        )
    })

    return (
        <section className="grid philoshophy" data-header-color={headerColor}>
            <Text tag="h2" className="philoshophy__s1" set="title" {...props} />
            <Text tag="div" className="philoshophy__s2" set="description" {...props} />
            <div className="philoshophy__s3">
                {cards()}
            </div>
            <div className="philoshophy__s4">
                <PrimaryButton set="buttonBook" {...props} />
                <Text set="buttonWebsite" {...props} tag="div" className="button-visit"></Text>
            </div>
            <div className="v-parallax background-wrapper">
                <div className="parallax--content no-scale">
                    <img src={banner} width="2492" height="1450" />
                </div>
            </div>
        </section>
    )

}