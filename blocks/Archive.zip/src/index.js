import './assets/styles/main.scss';

import { registerBlockType } from "@wordpress/blocks";
import Controller from "./components/helper/Controller"
import { ColorPicker } from '@wordpress/components';
import { TextControl } from '@wordpress/components';
import { sanitizeInput } from './components/helper/Libs';
const Blocks = [
  {
    id: "nolsis/home-page-banner",
    path: "HomePageBanner",
    title: 'Home page banner'
  },

  {
    id: "nolsis/latest-news",
    path: "NewsListing",
    title: 'Resto',
    dynamic: true
  },
  {
    id: "nolsis/latest-running-text",
    path: "RunningTextBanner",
    title: 'Marque Banner'
  },
  {
    id: "nolsis/discover",
    path: "Discover",
    title: 'Column Text Parallax'
  },

  {
    id: "nolsis/booking-banner",
    path: "BookingBanner",
    title: 'Booking Banner'
  },

  {
    id: "nolsis/featured-banner",
    path: "FeaturedBanner",
    title: 'Featured Banner'
  },

  {
    id: "nolsis/featured-jumbotron",
    path: "Jumbotron",
    title: 'Jumbotron Banner'
  },

  {
    id: "nolsis/featured-marque-logo",
    path: "RunningLogo",
    title: 'Marque Logo With Text'
  },

  {
    id: "nolsis/text-two-column",
    path: "TwoColumnText",
    title: 'Two Column Text'
  },

  {
    id: "nolsis/text-two-column-logo",
    path: "TwoColumnTextWithLogo",
    title: 'Two Column Text With Logo'
  },

  {
    id: "nolsis/property-gallery",
    path: "GallerySection",
    title: 'Properties Gallery'
  },

  {
    id: "nolsis/development-banner",
    path: "DevelopmentBanner",
    title: 'Development Banner'
  },

  {
    id: "nolsis/featured-banner-two",
    path: "FeaturedBannerTwo",
    title: 'Banner with text'
  },

  {
    id: "nolsis/banner-contact",
    path: "BannerContact",
    title: 'Banner Contact'
  },

  {
    id: "nolsis/grid-card",
    path: "GridColumnCard",
    title: 'Grid Card'
  },

  {
    id: "nolsis/text-two-column-banner",
    path: "TwoColumnImage",
    title: 'Two Column Images'
  },

  {
    id: "nolsis/guest-services",
    path: "GuestServices",
    title: 'Guest Services'
  },

  {
    id: "nolsis/contact-banner",
    path: "ContactUsBanner",
    title: 'Contact Us Banner'
  },

  {
    id: "nolsis/follow-us-banner",
    path: "FollowUsBanner",
    title: 'Follow Us Banner'
  },

  {
    id: "nolsis/property-banner",
    path: "PropertyHeroBanner",
    title: 'Property Hero Banner'
  },

  {
    id: "nolsis/philosophy-section",
    path: "OurPhilosophy",
    title: 'Our Philosophy'
  },

  {
    id: "nolsis/vision-connection",
    path: "VissionAndConnection",
    title: 'Vission and Connection'
  },

  {
    id: "nolsis/tema",
    path: "Team",
    title: 'Team'
  },

  {
    id: "nolsis/milestone",
    path: "CompanyMileStone",
    title: 'Compnay Milestone'
  },

  {
    id: "nolsis/about-us-banner",
    path: "AboutUsBanner",
    title: 'About Us Banner'
  },

  {
    id: "nolsis/gift-card",
    path: "GiftCard",
    title: 'Gift Card'
  }

]


for (let i = 0; i < Blocks.length; i++) {
  const block = Blocks[i]
  const template = require(`./components/${block.path}`)

  registerBlockType(block.id, {
    apiVersion: 3,
    title: block.title,
    icon: 'universal-access-alt',
    category: 'design',
    edit: props => {
      props = { ...props }
      props.edit = true
      props.id = block.id


      const { attributes, setAttributes } = props
      const { headerColor, customSectionClassName } = attributes;

      const onChangeBackgroundColor = (newColor) => {
        setAttributes({ headerColor: newColor });
      };

      return (<>
        <Controller {...props}>
          <fieldset>
            <TextControl label="Section Class" value={customSectionClassName} onChange={val => {
              props.setAttributes({
                'customSectionClassName': sanitizeInput(val)
              })
            }} />
            <label>Header Background</label>
            <ColorPicker color={headerColor}
              onChangeComplete={(color) => onChangeBackgroundColor(color.hex)}
              disableAlpha />
          </fieldset>
        </Controller>
        {template.default(props)}
      </>)
    },
    save: (props) => {
      if (block.dynamic) return null
      return template.default(props)
    },
    attributes: Object.assign(template.attributes, {
      headerColor: {
        type: 'string',
        default: '#FFF'
      },
      customSectionClassName: {
        type: 'string',
        default: ''
      }
    })
  })
}
